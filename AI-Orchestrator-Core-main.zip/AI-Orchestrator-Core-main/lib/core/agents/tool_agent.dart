import 'package:ai_orchestrator/core/agents/base_agent.dart';
import 'package:ai_orchestrator/core/agents/shared_context.dart';
import 'package:ai_orchestrator/core/tools/tool.dart';

/// Abstract contract for the tool agent role.
///
/// The [ToolAgent] is the **tool execution specialist** of the multi-agent
/// system.  Its responsibilities are:
///
/// - Maintain a registry of available [Tool] instances.
/// - Select the appropriate tool for a given natural-language instruction.
/// - Execute tools safely, capturing results and errors.
/// - Return a structured [ToolAgentResult] with the execution trace.
///
/// [ToolAgent] acts as the bridge between the language-model reasoning layer
/// and the concrete [Tool] implementations.  It never performs reasoning
/// itself; it receives a resolved tool call from the [ReasoningAgent] and
/// carries it out.
///
/// Dependency rule:
///   core/agents/ ← features/ tool-agent implementations
///   core/agents/ → core/tools/, core/ only (no native/ imports here)
abstract class ToolAgent extends BaseAgent {
  /// Executes the tool identified by [toolId] with the given [params].
  ///
  /// Returns a [ToolAgentResult] wrapping the raw [ToolResult].
  Future<ToolAgentResult> executeTool(
    String toolId,
    Map<String, dynamic> params,
    SharedContext context,
  );

  /// Registers [tool] so it becomes available for execution.
  void registerTool(Tool tool);

  /// Removes the tool identified by [toolId] from the registry.
  void deregisterTool(String toolId);

  /// Returns a view of all currently registered tools, keyed by [Tool.id].
  Map<String, Tool> get availableTools;

  /// Returns `true` when a tool with [toolId] is registered.
  bool hasTool(String toolId);

  // TODO(future): add discoverTools() to auto-register tools from PluginRegistry.
  // TODO(future): add List<String> get toolSchemas for LLM function-calling.
}

/// Result produced by [ToolAgent.executeTool].
class ToolAgentResult {
  const ToolAgentResult({
    required this.agentId,
    required this.toolId,
    required this.toolResult,
    this.success = true,
    this.error,
  });

  /// Identifier of the [ToolAgent] that handled the execution.
  final String agentId;

  /// Identifier of the [Tool] that was called.
  final String toolId;

  /// Raw result from the [Tool] execution.
  final ToolResult toolResult;

  /// Whether the overall execution succeeded (agent + tool layers).
  final bool success;

  /// Error description when [success] is `false`.
  final String? error;

  @override
  String toString() =>
      'ToolAgentResult(agentId: $agentId, toolId: $toolId, '
      'success: $success)';
}
