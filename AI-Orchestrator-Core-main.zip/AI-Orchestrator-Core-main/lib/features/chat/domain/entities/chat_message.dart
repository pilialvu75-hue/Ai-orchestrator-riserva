// Re-exported from core for backward compatibility.
// The canonical definition lives in core/orchestrator/state_engine/chat_message.dart
// so that OrchestratorStateEngine can reference it without importing features/.
export 'package:ai_orchestrator/core/orchestrator/state_engine/chat_message.dart';
